// griffin willingham
// alaskan bull worm
// cyen 3013
// oct 2025
// XOR crypto

package main

import (
	"fmt"
	"io"
	"log"
	"os"
)

const (
	KEY = "key" // file path of the key
)

// helper method to store the standard input
// thank you cameron !!!
func storeStdin() []byte {

	//fmt.Println("GETTING STDIN")

	// first, ensure that standard input has been redirected
	stat, _ := os.Stdin.Stat()
	if (stat.Mode() & os.ModeCharDevice) != 0 {
		fmt.Print("STDIN not redirected :(")
		os.Exit(0)
	}
	// attempt to read the stdin by storing it and error checking

	//fmt.Println("READING STDIN")

	input, err := io.ReadAll(os.Stdin)
	// if there is an error while reading stdin
	if err != nil {
		// kill program
		fmt.Print("STDIN error")
		os.Exit(0)
	}

	//fmt.Println("BYTE ARRAY RETURNED")
	return input
}

func getKey() []byte {
	//fmt.Println("GETTING KEY")
	temp, err := os.ReadFile(KEY)
	if err != nil {
		log.Fatalf(" ERR!! CAN'T READ KEY : %v", err)
	}

	//out := ""
	//fmt.Printf(" raw key byte array: %d", temp)
	//for _, seq := range temp {
	//out = out + fmt.Sprintf("%08b", seq)
	//}
	//fmt.Printf(" byte array to str : %s", out)

	//return out

	return temp

}

func main() {
	// get input from user
	intext := storeStdin()

	// fmt.Println("INTEXT")
	// fmt.Print(intext)

	//fmt.Println("")

	key_initial := getKey()

	//fmt.Println("KEY")
	//fmt.Print(key_initial)

	// make sure key length is >= to text length by sticking a dupe of key onto the end
	key := key_initial
	for len(key) <= len(intext) {
		key = append(key, key_initial...)
	}

	// XOR those with the key
	var out []byte
	for k, _ := range intext { // for every byte in the array
		temp := intext[k] ^ key[k]
		out = append(out, temp)
	}

	//fmt.Println()
	//fmt.Println("OUT")
	// out2 := fmt.Sprintf("%08b", out)
	// out2 = strings.ReplaceAll(strings.Trim(out2, "[]"), " ", "")

	fmt.Print(string(out))

}
