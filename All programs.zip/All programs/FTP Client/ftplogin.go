package main

import (
	"fmt"
	"log"
	"path"
	"strconv"
	"strings"
	"time"

	"github.com/secsy/goftp"
)

const (
	address  = "138.47.99.29"
	port     = "21"
	username = "anonymous"
	password = ""
	rootPath = "/10/"
	mode     = 10
)

func main() {
	config := goftp.Config{
		User:            username,
		Password:        password,
		Timeout:         10 * time.Second,
		ActiveTransfers: true,
	}
	c, err := goftp.DialConfig(config, address+":"+port)
	if err != nil {
		log.Fatal(err)
	}
	defer c.Close()
	var bits []byte
	if mode == 10 {
		recursive10(c, rootPath, &bits)
	} else {
		recursive7(c, rootPath, &bits)
	}

	msg := decode7(string(bits))
	fmt.Print(strings.TrimRight(msg, "\x00"))
}

func recursive10(c *goftp.Client, p string, bits *[]byte) {
	items, err := c.ReadDir(p)
	if err != nil {
		log.Fatal(err)
	}
	for _, itm := range items {
		perms := itm.Mode().String()
		for i := 0; i < 10; i++ {
			if perms[i] == '-' {
				*bits = append(*bits, '0')
			} else {
				*bits = append(*bits, '1')
			}
		}
	}
}

func recursive7(c *goftp.Client, p string, bits *[]byte) {
	items, err := c.ReadDir(p)
	if err != nil {
		log.Fatal(err)
	}
	for _, itm := range items {
		perms := itm.Mode().String()
		if len(perms) >= 10 && !itm.IsDir() && perms[0:3] == "---" {
			for i := 3; i < 10; i++ {
				if perms[i] == '-' {
					*bits = append(*bits, '0')
				} else {
					*bits = append(*bits, '1')
				}
			}
		}
		if itm.IsDir() {
			recursive7(c, path.Join(p, itm.Name()), bits)
		}
	}
}

func decode7(bits string) string {
	r := len(bits) % 7
	if r != 0 {
		bits += strings.Repeat("0", 7-r)
	}
	out := make([]byte, 0, len(bits)/7)
	for i := 0; i < len(bits); i += 7 {
		val, _ := strconv.ParseUint(bits[i:i+7], 2, 8)
		out = append(out, byte(val))
	}
	return string(out)
}
