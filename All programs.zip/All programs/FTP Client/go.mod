module awesomeProject4

go 1.25

require github.com/secsy/goftp v0.0.0-20200609142545-aa2de14babf4
