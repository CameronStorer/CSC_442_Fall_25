package main

import (
	"fmt"
	"io"
	"os"
	"strings"
)



// letterShift returns 0..25 for a-z/a-z and -1 otherwise
func letterShift(r rune) int {
	switch {
	case r >= 'A' && r <= 'Z':
		return int(r - 'A')
	case r >= 'a' && r <= 'z':
		return int(r - 'a')
	default:
		return -1
	}
}

// buildKeyShifts turns the key into a slice of shifts (0..25)
// spaces (and any non-letters) are ignored
func buildKeyShifts(key string) []int {
	var shifts []int
	for _, r := range key {
		if s := letterShift(r); s >= 0 {
			shifts = append(shifts, s)
		}
	}
	return shifts
}

// applyShift shifts a single letter by s places, keeping case
// for decrypt, s should be negative (handled by caller)
func applyShift(r rune, s int) rune {
	if r >= 'A' && r <= 'Z' {
		base := int('A')
		return rune((int(r)-base+s+26*1000)%26 + base)
	}
	if r >= 'a' && r <= 'z' {
		base := int('a')
		return rune((int(r)-base+s+26*1000)%26 + base)
	}
	return r
}

// vigenere applies the cipher to text using shifts; enc = true => encrypt, false => decrypt
func vigenere(text string, shifts []int, enc bool) string {
	if len(shifts) == 0 {
		return text
	}
	var b strings.Builder
	b.Grow(len(text))

	k := 0 // index into shifts for letters only
	for _, r := range text {
		// keep non-letters unchanged and don't advance the key
		if letterShift(r) == -1 {
			b.WriteRune(r)
			continue
		}
		s := shifts[k%len(shifts)]
		if !enc {
			s = -s
		}
		b.WriteRune(applyShift(r, s))
		k++
	}
	return b.String()
}

func main() {
	// expect: program, mode (-e or -d), key (possibly quoted)
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: vigenere -e|-d <key>")
		os.Exit(2)
	}
	mode := os.Args[1]
	// join in case someone passed key as multiple args without quotes
	key := strings.Join(os.Args[2:], " ")

	shifts := buildKeyShifts(key)
	if len(shifts) == 0 {
		fmt.Fprintln(os.Stderr, "error: key must contain at least one letter (a-z)")
		os.Exit(2)
	}

	data, err := io.ReadAll(os.Stdin)
	if err != nil {
		fmt.Fprintln(os.Stderr, "read error:", err)
		os.Exit(1)
	}

	switch mode {
	case "-e":
		fmt.Print(vigenere(string(data), shifts, true))
	case "-d":
		fmt.Print(vigenere(string(data), shifts, false))
	default:
		fmt.Fprintln(os.Stderr, "usage: vigenere -e|-d <key>")
		os.Exit(2)
	}
}
